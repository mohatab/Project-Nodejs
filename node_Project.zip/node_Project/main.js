require("dotenv").config();
const express = require("express");
const mongoose = require("mongoose");
const User = require("./models/users");
const Book = require("./models/users");
const app = express();
const PORt = process.env.PORt || 5000;

app.use(express.json());
app.use(express.urlencoded({ extended: false }));

//Get Api
app.get("/", (req, res) => {
  res.send("Hello from Node Api");
});

//Get all users
app.get("/api/users", async (req, res) => {
  try {
    const users = await User.find({});
    res.status(200).json(users);
  } catch (error) {
    res.status(500).json({ message: err.message });
  }
});

//Get Single users by Id
app.get("/api/user/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const users = await User.findById(id);
    res.status(200).json(users);
  } catch (error) {
    res.status(500).json({ message: err.message });
  }
});

//add users to data base
app.post("/api/users", async (req, res) => {
  try {
    const users = await User.create(req.body);
    res.status(200).json(users);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Update User
app.put("/api/user/:id", async (req, res) => {
  try {
    const { id } = req.params;

    // Find and update the user by ID
    const updatedUser = await User.findByIdAndUpdate(id, req.body, {
      new: true,
    });

    if (!updatedUser) {
      return res.status(404).json({ message: "User not found" });
    }

    // Return the updated user
    res.status(200).json(updatedUser);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

//Delete
app.delete("/api/user/:id", async (req, res) => {
  try {
    const { id } = req.params;

    // Find and Delete the user by ID
    const deletedUser = await User.findByIdAndDelete(id, req.body, {
      new: true,
    });

    if (!deletedUser) {
      return res.status(404).json({ message: "User not found" });
    }
    res.status(200).json({ message: "User deleted Successfully" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

//Search
app.get("/api/search", async (req, res) => {
  const { title, author, genre } = req.query;

  let filter = {};

  if (title) {
    filter.title = { $regex: title, $options: "i" };
  }
  if (author) {
    filter.author = { $regex: author, $options: "i" };
  }
  if (genre) {
    filter.genre = { $regex: genre, $options: "i" };
  }

  try {
    const books = await Book.find(filter);
    res.status(200).json(books);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// database connection
mongoose.connect(process.env.DB_URI, {});
const db = mongoose.connection;
db.on("error", (error) => console.log(error));
db.once("open", () => console.log("connected to the database"));

app.listen(PORt, () => {
  console.log("Server started at http://localhost:5000");
});
